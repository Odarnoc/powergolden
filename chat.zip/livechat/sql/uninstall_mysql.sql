DROP TABLE %db_name%.mirrormx_customer_chat_user;
DROP TABLE %db_name%.mirrormx_customer_chat_message;